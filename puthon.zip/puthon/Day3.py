#!/usr/bin/env python
# coding: utf-8

# In[13]:


time=1
flag=3
bill=1
while flag>0:
    userinput=input("enter thr time ")
    lst= userinput.split()
    if(len(lst)<2):
        print("wrong input")
        flag-=1
    else:
        if(lst[1].lower()=='hrs' or lst[1].lower()=='hours'):
              time=int(lst[0])*60*60
              flag=0
                
        if(lst[1].lower()=='min' or lst[1].lower()=='minutes'):
              time=int(lst[0])*60
              flag=0
                
        if(lst[1].lower()=='sec' or lst[1].lower()=='seconds'):
              time=int(lst[0])
              flag=0
        else:
            
            flag-=1
            print("wrong input")
        if(flag==0):
            bill=time*0.1
            print("the bill in rs",bill)

       
    
        


# In[16]:


from math import pi
def perimeter(radius):
    perimeter = 2*pi*radius
    return perimeter
def area(radius):
    area =  pi*radius*radius
    return area
def rad():
    radius = int(input("Enter Radius : "))
    return radius

radii= rad()
perimete= perimeter(radii)
are= area(radii)
print(" Area of the circle is : ",are)
print(" Perimeter of the circle is : ",perimete)


# In[22]:


def stringinput():
    st=input("Enter string: ") 
    return st
def special(string):
    count=0
    for char in string:
        if not char.isalnum():
            count+=1
    return count

string = stringinput() 

print ("Special count", special(string))


# In[23]:


def intinput():
    st=int(input("Enter number: ") )
    return st

def check(num):
    if(num%2==0):
        return 'even'
    else:
        return 'odd'
num=intinput()
print("No is",check(num))


# In[ ]:


def reversefun(a):
    no = str(a)
    return no[::-1]
        
def inputfun():
    count =0
    while count<=3:
        no = int(input("Enter a number : "))
        if no==0 or no<0:
            print("Invalid Input, Please enter a positive no")
            count+=1
        else:
            count = 4
            return no
collectno= inputfun()
b = reversefun(collectno)
print("Reverse of the no is ",b)


# In[ ]:


def palindrome(inp_string):
    
    if inp_string[::-1].lower() == inp_string.lower():
        print("Palindrome String")
    else:
        print("Not a Palindrome String")
    
def inputfun():
    stringinp= input("Enter the string : ")
    return stringinp
collect_string = inputfun()
palindrome(collect_string)


# In[26]:


def inputs():
    sp=int(input("enter the selling price"))
    cp=int(input("enter the cost price"))
    return sp,cp

def calc(sp,cp):
    if(sp>cp):
        return sp-cp,1
    if(cp>sp):
        return cp-sp,2
    else:
        return 0,3
sellprice,costprice=inputs()

ans,typeofcalc=calc(sellprice,costprice)

if(typeofcalc==1):
    print("Profit is",ans)

if(typeofcalc==2):
    print("loss is",ans)
if(typeofcalc==3):
    print("No loss/profit")

    


# In[30]:


def inputs():
    name=input("enter the name")
    age=int(input("enter the age"))
    address=input("Enter the address")
    return name,age,address
def check_name(name):
    count=0
    for i in name:
        if(i=='a' or i=='e' or i=='o' or i=='u'):
            count=count+1
    print("count of vowel",count) 
def check_age(age):
    if(age>18):
        print("Adult")
    else:
        print("Not adult")
def check_address(address):
    str='delhi'
    flag=0
    if(address.count(str)>0):
        flag=1;
    str2='new delhi'
    flag2=0
    if(address.count(str2)>0):
        flag2=1
    
    if(flag==1 and flag2==0):
        print("success")
    else:
        print("No success")
name,age,address=inputs()
check_name(name)
check_age(age)
check_address(address)

    
    
    
        


# In[2]:


import string
def inputs():
    str=input("Enter the string")
    return str
def countwords(str):
    noofwords=str.split()
    print("no of words",len(noofwords)),
def maxchar(str):
    noofwords=str.split()
    maxv=0
    maxc=''
    for i in noofwords:
           if(len(i)>maxv):
                maxv=len(i)
                maxc=i
    print("Word with most char", maxc)
def special(str):

    words=str.split()
    count=0
    for i in words:
        if(not i.isalnum()):
            print(i)
        
                  
    
    
str=inputs()
countwords(str)
maxchar(str)
special(str)


# In[ ]:




