#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import string
import numpy as np


# In[2]:


df=pd.read_csv(r'C:\Users\Administrator\Downloads\wine.csv')
df


# In[3]:


# remove all special chars and space from the column names
collist=[]
for col in df.columns:
    str=''
    for i in col:
        if i not in string.punctuation and i!=' ':
            str+=i
    collist.append(str)
df.columns=collist
df


# In[4]:


# count the missing values in every column
	
df.isna().sum()


# In[5]:


# replace all the cells having special chars with NaN

df.replace(string.punctuation,np.nan)


# In[6]:


# count the missing values in every column after replacing special char with NaN
df.isnull().sum()


# In[7]:


# - find the missing value ratio for every column (MVR = missing value count/ total number of values in that column)
mvr = df.isnull().sum() / len(df)
mvr


# In[8]:


# convert customer_segment values to numeric 1,2,3 for all 3 categories
df['customersegment']=df['customersegment'].str.lower()
df['customersegment']=df['customersegment'].replace({'one':'1','two':'2','three':'3'})
df


# In[19]:


# remove special char from datframe
str=string.punctuation
for col in df:
    if (df[col].dtypes==object):
        df[col] = df[col].str.replace('[!#$%&,]', '')
df.dtypes


# In[10]:


#convert into float
str=string.punctuation
for col in df:
    if (df[col].dtypes==object):
           df[col]=df[col].astype(float)
df


# In[20]:


df.dtypes


# In[12]:


#  convert all values upto 2 decimal places
df.round(decimals=2)


# In[13]:


# find the variance in every column.
df.var()


# In[14]:


# find correlation between variables (only independent vars - ignoring customer_segment)
df[df.columns[1:13]].corr()


# In[15]:


# plot heatmap for the correlation between variables
import seaborn as sb
import matplotlib.pyplot as mp
 
# plotting correlation heatmap
dataplot = sb.heatmap(df[df.columns[1:13]].corr())
  
# displaying heatmap
mp.show()


# In[16]:


# import seaborn as sns
# for col in df:
#     sns.boxplot(x=df[col])
df


# In[23]:


# plot a scatter plot for Alcohol and Malic Acid to depict relation between them
mp.scatter(df['Alcohol'], df['Malicacid']);


# In[21]:


import seaborn as sns
import matplotlib.pyplot as plt
 
# read a tips.csv file from seaborn library

 
# count plot on single categorical variable
sns.countplot(x ='customersegment', data = df)
 
# Show the plot
plt.show()


# In[ ]:




