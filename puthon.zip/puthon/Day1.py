#!/usr/bin/env python
# coding: utf-8

# In[1]:


print("Hello")


# In[2]:


a=10


# In[3]:


print("amnount is ",a)


# In[16]:


from math import pi
r=5
area=pi*r*r
perimeter=2*pi*r
print("Area of Circle: ",area)
print("Perimeter of Circle: ",perimeter)


# In[6]:



p= 300000
n=5
r = 5
si = (p * n * r)/100
print("Simple interest",si)


# In[7]:


from math import sqrt

base = 30
height = 50
ans = sqrt(base**2 + height**2)
print("The length of the hypotenuse is:", ans )


# In[10]:


length=10
breadth=5
area= length *breadth;
perimeter=2 * (length+breadth)
print("The area is:", area )
print("The perimeter is:", perimeter )


# In[15]:


fname="Jhon"
lname="Mathew"
fullname=fname+" "+lname
print(fullname)


# In[12]:


print ("The ASCII value of A is", ord('A'))  
print ("The ASCII value of B is", ord('B'))  
print ("The ASCII value of a is", ord('a'))  
print ("The ASCII value of b is", ord('b'))  


# In[14]:


speed=30
time= 0.5
distance= speed *time
print("The distance(km) is:", distance )


# In[21]:


costprice=int(input("Enter the cost price"))
sellprice=int(input("Enter the selling price"))
ans=0
if(costprice==sellprice):
    print("No profit/loss")

elif(costprice>sellprice):
    ans=costprice-sellprice
    print("loss is",ans)
else:
    ans=sellprice-costprice
    print("profit is ",ans)
    


# In[22]:


user=input("Enter the name")
ans=len(user);
print("Lenght of name is ",ans)


# In[35]:


math=int(input("Enter the maths marks"))
english=int(input("Enter the english marks"))
science=int(input("Enter the science marks"))
hindi=int(input("Enter the hindi marks"))

percentage=(math+english+science+hindi)/4.0
print("Percentage is ",percentage)

if(math>english and math>science and math >hindi):
    print("Maximum marks:",maths)
    print("Maximum marks subject maths")
    
if(english>math and english >science and english>hindi):
        print("Maximum marks:",english)
        print("Maximum marks subject English")
        
if(science>math and science > english and science > hindi):
    print("Maximum marks:",science)
    print("Maximum marks subject science")
if(hindi >math and hindi>science and hindi>english):
    print("Maximum marks:",hindi)
    print("Maximum marks subject hindi")
    
    
    
    
    
if(math<english and math<science and math <hindi):
    print("Min marks:",maths)
    print("Min marks subject maths")
    
if(english<math and english <science and english<hindi):
        print("Min marks:",english)
        print("Min marks subject English")
        
if(science<math and science < english and science < hindi):
    print("Min marks:",science)
    print("Min marks subject science")
if(hindi < math and hindi<science and hindi<english):
    print("Min marks:",hindi)
    print("Min marks subject hindi")
            


# In[38]:


a=input("Enter the string")
upper=0
lower=0
for i in a:
    if(i=='a' or i=='e' or i=='i' or i=='o' or i=='u'):
        lower=lower+1
    if(i=='A'or i=='E' or i=='I'or i=='O' or i=='U' ):
        upper=upper+1
print("Count of lower case vowels ",lower)
print("Count of upper case vowels ", upper)
    
    
    


# In[ ]:




